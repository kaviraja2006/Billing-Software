import React, { useMemo } from 'react';
import { Button } from '../../../components/ui/Button';

const BottomFunctionBar = ({ onFunctionClick }) => {
    const functions = useMemo(() => [
        { key: 'F3', label: 'Item Discount' },
        { key: 'F4', label: 'Remove Item' },
        { key: 'F6', label: 'Change Quantity' },
        { key: 'F8', label: 'Additional Charges' },
        { key: 'F9', label: 'Bill Discount' },
        { key: 'F10', label: 'Loyalty Points' },
        { key: 'F12', label: 'Remarks' },
    ], []);

    return (
        <div className="grid grid-cols-4 lg:grid-cols-8 gap-3 p-3 bg-white/80 backdrop-blur-md border-t border-zinc-200 shadow-[0_-4px_20px_-5px_rgba(0,0,0,0.05)] z-10">
            {functions.map((fn) => (
                <Button
                    key={fn.key}
                    variant="outline"
                    className="flex flex-col items-center justify-center h-14 bg-white hover:bg-zinc-50 border-zinc-200 hover:border-zinc-300 shadow-sm hover:shadow transition-all duration-200 rounded-xl group"
                    onClick={() => onFunctionClick(fn.key)}
                >
                    <span className="text-xs font-bold text-zinc-900 mb-0.5">{fn.key}</span>
                    <span className="text-[10px] font-medium text-zinc-500 group-hover:text-zinc-700 uppercase tracking-wide">{fn.label}</span>
                </Button>
            ))}
        </div>
    );
};

export default React.memo(BottomFunctionBar);
