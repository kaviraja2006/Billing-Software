import React, { useState, useEffect, useRef } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../../components/ui/Table';
import { Button } from '../../../components/ui/Button';
import { Trash2, Plus, Minus, Percent, AlertTriangle } from 'lucide-react';
import { Input } from '../../../components/ui/Input';

// Separate component for quantity input to handle local state
const QuantityInput = ({ item, updateQuantity, isOverStock }) => {
    const [localValue, setLocalValue] = useState(item.quantity.toString());
    const inputRef = useRef(null);
    const hasStockLimit = item.stock !== undefined && item.stock !== null;
    const availableStock = item.stock ?? 0;

    // Sync local value with item quantity when it changes externally
    useEffect(() => {
        setLocalValue(item.quantity.toString());
    }, [item.quantity]);

    const handleChange = (e) => {
        const value = e.target.value;
        // Allow empty string or valid numbers
        if (value === '' || /^\d+$/.test(value)) {
            setLocalValue(value);
        }
    };

    const handleBlur = () => {
        // On blur, commit the value
        const numValue = parseInt(localValue) || 0;
        if (numValue < 1) {
            // If 0 or invalid, reset to 1
            setLocalValue('1');
            updateQuantity(item.id || item._id, 1);
        } else {
            const finalValue = hasStockLimit ? Math.min(numValue, availableStock) : numValue;
            setLocalValue(finalValue.toString());
            updateQuantity(item.id || item._id, finalValue);
        }
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            inputRef.current?.blur();
        }
    };

    return (
        <Input
            ref={inputRef}
            type="text"
            inputMode="numeric"
            value={localValue}
            onChange={handleChange}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
            className={`w-12 h-8 p-0 text-center font-bold text-zinc-900 bg-white border border-zinc-200 focus:border-zinc-900 focus:ring-1 focus:ring-zinc-900 rounded-md shadow-sm text-sm ${isOverStock ? 'border-red-500 bg-red-50' : ''}`}
            onClick={(e) => e.stopPropagation()}
        />
    );
};

const BillingGrid = ({ cart, updateQuantity, removeItem, selectedItemId, onRowClick, onDiscountClick }) => {
    return (
        <div className="flex-1 overflow-auto bg-white border rounded-none shadow-none h-full relative">
            <Table>
                <TableHeader className="bg-zinc-50/90 backdrop-blur sticky top-0 z-10 shadow-sm border-b border-zinc-200">
                    <TableRow className="hover:bg-transparent h-11 border-b border-zinc-200">
                        <TableHead className="w-10 text-center font-bold text-zinc-700">#</TableHead>
                        <TableHead className="font-bold text-zinc-700">Item Code</TableHead>
                        <TableHead className="w-1/3 font-bold text-slate-700">Item Name</TableHead>
                        <TableHead className="w-28 text-center font-bold text-slate-700">Qty</TableHead>
                        <TableHead className="font-bold text-slate-700">Unit</TableHead>
                        <TableHead className="text-right font-bold text-slate-700">Price</TableHead>
                        <TableHead className="text-right font-bold text-slate-700">Disc.</TableHead>
                        <TableHead className="text-right font-bold text-slate-700">Tax %</TableHead>
                        <TableHead className="text-right font-bold text-slate-700">Tax</TableHead>
                        <TableHead className="text-right font-bold text-slate-700">Total</TableHead>
                        <TableHead className="w-16 text-center font-bold text-slate-700">Action</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {cart.map((item, index) => {
                        const isSelected = (item.id || item._id) === selectedItemId;
                        const hasStockLimit = item.stock !== undefined && item.stock !== null;
                        const isOverStock = hasStockLimit && item.quantity > item.stock;
                        const availableStock = item.stock ?? 0;
                        
                        return (
                            <TableRow
                                key={item.id || item._id || index}
                                className={`cursor-pointer transition-all h-12 border-b border-zinc-100 last:border-0 ${isSelected ? 'bg-zinc-50 border-l-4 border-l-zinc-900 shadow-inner' : 'hover:bg-zinc-50/50'} ${isOverStock ? 'bg-red-50' : ''}`}
                                onClick={() => onRowClick(item.id || item._id)}
                            >
                                <TableCell className="text-center py-1">{index + 1}</TableCell>
                                <TableCell className="font-mono text-xs py-1 text-slate-600">{item.sku || item.barcode || 'N/A'}</TableCell>
                                <TableCell className="font-medium text-sm py-1 text-slate-900">
                                    <div className="flex items-center gap-1">
                                        {item.name}
                                        {hasStockLimit && availableStock <= 5 && (
                                            <span className="text-[10px] text-amber-600 font-medium flex items-center gap-0.5">
                                                <AlertTriangle size={10} />
                                                {availableStock} left
                                            </span>
                                        )}
                                    </div>
                                </TableCell>
                                <TableCell className="py-1">
                                    <div className="flex items-center justify-center gap-1">
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            className="h-7 w-7 bg-white border-zinc-200 hover:bg-zinc-50 hover:border-zinc-300 text-zinc-600 rounded-md"
                                            onClick={(e) => { e.stopPropagation(); updateQuantity(item.id || item._id, parseInt(item.quantity) - 1); }}
                                        >
                                            <Minus size={10} className="text-slate-600" />
                                        </Button>
                                        <QuantityInput
                                            item={item}
                                            updateQuantity={updateQuantity}
                                            isOverStock={isOverStock}
                                        />
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            className={`h-7 w-7 bg-white border-zinc-200 hover:bg-zinc-50 hover:border-zinc-300 text-zinc-600 rounded-md ${hasStockLimit && item.quantity >= availableStock ? 'opacity-50 cursor-not-allowed' : ''}`}
                                            onClick={(e) => { e.stopPropagation(); updateQuantity(item.id || item._id, parseInt(item.quantity) + 1); }}
                                            disabled={hasStockLimit && item.quantity >= availableStock}
                                        >
                                            <Plus size={10} className="text-slate-600" />
                                        </Button>
                                    </div>
                                </TableCell>
                                <TableCell className="py-1 text-xs text-slate-500">{item.unit || 'PCS'}</TableCell>
                                <TableCell className="text-right font-medium py-1 text-slate-700">₹{(item.price || item.sellingPrice || 0).toFixed(2)}</TableCell>
                                <TableCell className="text-right text-black font-medium py-1 text-xs">{item.discount > 0 ? `₹${item.discount.toFixed(2)}` : '-'}</TableCell>
                                <TableCell className="text-right text-slate-600 py-1 text-xs">
                                    {item.taxRate ? `${item.taxRate}%` : <span className="text-neutral-500 font-bold">0%</span>}
                                </TableCell>
                                <TableCell className="text-right text-slate-500 py-1 text-xs" title={`CGST: ${item.cgst?.toFixed(2) || 0}, SGST: ${item.sgst?.toFixed(2) || 0}, IGST: ${item.igst?.toFixed(2) || 0}`}>
                                    {item.taxAmount !== undefined
                                        ? `₹${item.taxAmount.toFixed(2)}`
                                        : `₹${((Math.max(0, (item.price || 0) * item.quantity - (item.discount || 0))) * (item.taxRate || 0) / 100).toFixed(2)}`
                                    }
                                </TableCell>
                                <TableCell className="text-right font-bold text-sm py-1 text-slate-900">₹{item.total.toFixed(2)}</TableCell>
                                <TableCell className="py-1">
                                    <div className="flex items-center justify-center gap-1">
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            className="h-8 w-8 text-slate-400 hover:text-black hover:bg-neutral-200 rounded-full"
                                            title="Remove Item"
                                            onClick={(e) => { e.stopPropagation(); removeItem(item.id || item._id); }}
                                        >
                                            <Trash2 size={16} />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        );
                    })}
                    {/* Empty Rows Fillers to look like POS */}
                    {Array.from({ length: Math.max(0, 10 - cart.length) }).map((_, i) => (
                        <TableRow key={`empty-${i}`} className="h-10 hover:bg-transparent border-dashed border-b border-zinc-100">
                            <TableCell className="text-zinc-200 text-center text-xs">{cart.length + i + 1}</TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
};

// Use simple React.memo without custom comparison - default shallow comparison is faster
export default React.memo(BillingGrid);
