import { syncService } from '../../services/syncService';
import React, { useState, useEffect, useRef, useMemo, useLayoutEffect, useCallback, useDeferredValue } from 'react';
import { calculateTotals } from '../../utils/billingUtils';
import { printReceipt } from '../../utils/printReceipt';
import { normalizeSearchText } from '../../utils/searchUtils';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Search, X, Settings, Minus, Plus, RefreshCcw } from 'lucide-react';
import { useTransactions } from '../../context/TransactionContext';
import { useProducts } from '../../context/ProductContext';
import { useCustomers } from '../../context/CustomerContext';
import { useToast } from '../../context/ToastContext';
import BillingGrid from './components/BillingGrid';
import BillingSidebar from './components/BillingSidebar';
import BottomFunctionBar from './components/BottomFunctionBar';
import useKeyboardShortcuts from '../../hooks/useKeyboardShortcuts';
import { DiscountModal } from './components/modals/DiscountModal';
import { RemarksModal } from './components/modals/RemarksModal';
import { AdditionalChargesModal } from './components/modals/AdditionalChargesModal';
import { LoyaltyPointsModal } from './components/modals/LoyaltyPointsModal';
import CustomerSearchModal from './components/CustomerSearchModal';
import QuantityModal from './components/QuantityModal';
import VariantSelectionModal from './components/VariantSelectionModal';
import ConfirmationModal from '../../components/ui/ConfirmationModal';

// Update: Add F5 shortcut
import { useSettings } from '../../context/SettingsContext';

const BillingPage = () => {
    const { addTransaction } = useTransactions();
    const { products, refreshProducts } = useProducts();
    const { refreshCustomers, findOrCreateCustomer } = useCustomers();
    const { settings } = useSettings();
    const { addToast } = useToast();
    const searchInputRef = useRef(null);
    const suggestionsListRef = useRef(null);
    const [isProcessing, setIsProcessing] = useState(false);

    // --- State ---
    const [activeBills, setActiveBills] = useState(() => {
        try {
            const saved = sessionStorage.getItem('billing_activeBills');
            if (saved) {
                const parsed = JSON.parse(saved);
                if (Array.isArray(parsed) && parsed.length > 0) return parsed;
            }
        } catch (error) { console.error(error); }
        return [{ id: 1, customer: null, cart: [], totals: { grossTotal: 0, itemDiscount: 0, subtotal: 0, tax: 0, discount: 0, additionalCharges: 0, roundOff: 0, total: 0 }, gstSummary: {}, paymentMode: null, amountReceived: '', remarks: '', billDiscount: 0, additionalCharges: 0, loyaltyPointsDiscount: 0, status: 'Pending', taxType: 'Intra-State' }];
    });
    const [activeBillId, setActiveBillId] = useState(() => {
        try {
            const saved = sessionStorage.getItem('billing_activeBillId');
            if (saved) return parseInt(saved, 10);
        } catch (error) { console.error(error); }
        return 1;
    });
    const [selectedItemId, setSelectedItemId] = useState(null);
    const [modals, setModals] = useState({ itemDiscount: false, billDiscount: false, remarks: false, additionalCharges: false, loyaltyPoints: false, customerSearch: false, quantityChange: false, variantSelection: false, invoiceDelivery: false });
    const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
    const [savedInvoiceData, setSavedInvoiceData] = useState(null);
    const [selectedProductForVariant, setSelectedProductForVariant] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const deferredSearchTerm = useDeferredValue(searchTerm);
    const [searchActiveIndex, setSearchActiveIndex] = useState(-1);
    const [focusIndex, setFocusIndex] = useState(-1);
    const [mobileTab, setMobileTab] = useState('items');

    useEffect(() => { try { sessionStorage.setItem('billing_activeBills', JSON.stringify(activeBills)); } catch (e) { } }, [activeBills]);
    useEffect(() => { try { sessionStorage.setItem('billing_activeBillId', activeBillId.toString()); } catch (e) { } }, [activeBillId]);

    const currentBill = activeBills.find(b => b.id === activeBillId) || activeBills[0];

    // Safety check to prevent crashes if state is invalid
    if (!currentBill) {
        return <div className="flex items-center justify-center h-full">Loading Billing...</div>;
    }

    // --- Derived State (Memoized) ---
    const derivedBillingData = useMemo(() => {
        return calculateTotals(
            currentBill.cart,
            currentBill.billDiscount || 0,
            currentBill.additionalCharges || 0,
            currentBill.loyaltyPointsDiscount || 0,
            currentBill.taxType,
            settings
        );
    }, [
        currentBill.cart,
        currentBill.billDiscount,
        currentBill.additionalCharges,
        currentBill.loyaltyPointsDiscount,
        currentBill.taxType,
        settings
    ]);

    const { totals, gstSummary, enrichedCart } = derivedBillingData;

    const addNewBill = () => {
        const newId = Math.max(...activeBills.map(b => b.id)) + 1;
        setActiveBills([...activeBills, { id: newId, customer: null, cart: [], totals: { grossTotal: 0, itemDiscount: 0, subtotal: 0, tax: 0, discount: 0, additionalCharges: 0, roundOff: 0, total: 0 }, gstSummary: {}, paymentMode: null, amountReceived: '', remarks: '', billDiscount: 0, additionalCharges: 0, loyaltyPointsDiscount: 0, status: 'Pending', taxType: 'Intra-State' }]);
        setActiveBillId(newId);
        setSelectedItemId(null);
    };

    const closeBill = (id) => {
        if (activeBills.length === 1) {
            setActiveBills([{ id: 1, customer: null, cart: [], totals: { grossTotal: 0, itemDiscount: 0, subtotal: 0, tax: 0, discount: 0, additionalCharges: 0, roundOff: 0, total: 0 }, gstSummary: {}, paymentMode: null, amountReceived: '', remarks: '', billDiscount: 0, additionalCharges: 0, loyaltyPointsDiscount: 0, status: 'Pending', taxType: 'Intra-State' }]);
            setActiveBillId(1);
            setSelectedItemId(null);
            return;
        }
        const newBills = activeBills.filter(b => b.id !== id);
        setActiveBills(newBills);
        if (id === activeBillId) setActiveBillId(newBills[newBills.length - 1].id);
    };

    const updateCurrentBill = useCallback((updates) => {
        setActiveBills(prev => prev.map(bill => bill.id === activeBillId ? { ...bill, ...updates } : bill));
    }, [activeBillId]);

    const [triggerFocus, setTriggerFocus] = useState(0);

    const handleReset = () => {
        setIsResetConfirmOpen(true);
    };

    const performReset = () => {
        // 1. CLEAR STORAGE FIRST to prevent race conditions with useEffects
        try {
            sessionStorage.removeItem('billing_activeBills');
            sessionStorage.removeItem('billing_activeBillId');
        } catch (e) {
            console.error("Storage clear failed", e);
        }

        // 2. PREPARE CLEAN STATE
        const newBillId = Date.now();
        const cleanBill = {
            id: newBillId,
            customer: null,
            cart: [],
            totals: {
                grossTotal: 0, itemDiscount: 0, subtotal: 0, tax: 0, discount: 0, additionalCharges: 0, roundOff: 0, total: 0
            },
            gstSummary: {},
            paymentMode: null,
            amountReceived: '',
            remarks: '',
            billDiscount: 0,
            additionalCharges: 0,
            loyaltyPointsDiscount: 0,
            status: 'Pending',
            taxType: 'Intra-State'
        };

        // 3. BATCH STATE UPDATES
        setActiveBills([cleanBill]);
        setActiveBillId(newBillId);
        setSelectedItemId(null);
        setSearchTerm('');
        setModals({ itemDiscount: false, billDiscount: false, remarks: false, additionalCharges: false, loyaltyPoints: false, customerSearch: false, quantityChange: false, variantSelection: false, invoiceDelivery: false });
        setIsProcessing(false);
        setSavedInvoiceData(null);

        addToast('Billing session reset', 'success');

        // 4. TRIGGER FOCUS
        setTriggerFocus(prev => prev + 1);
    };

    // Robust Focus Management using useLayoutEffect
    // This runs synchronously after DOM mutations but before paint, 
    // ensuring the user sees the cursor immediately.
    useLayoutEffect(() => {
        if (triggerFocus > 0) {
            const focusSearch = () => {
                const input = document.getElementById('main-search-input');
                if (input) {
                    input.focus();
                    // Optional: Select text if any
                    // input.select(); 
                } else if (searchInputRef.current) {
                    searchInputRef.current.focus();
                }
            };

            // Immediate attempt
            focusSearch();

            // Backup attempt for safety (in case of complex re-renders)
            const timer = setTimeout(focusSearch, 50);
            return () => clearTimeout(timer);
        }
    }, [triggerFocus, activeBillId]); // Re-run on bill switch too

    // Auto-focus on Mount (Navigation to this page)
    useEffect(() => {
        // Trigger the robust focus logic
        setTriggerFocus(prev => prev + 1);
    }, []);



    // Search Logic
    const filteredProducts = useMemo(() => {
        if (!deferredSearchTerm) return [];
        const terms = deferredSearchTerm.toLowerCase().split(/\s+/).filter(t => t.trim());
        if (terms.length === 0) return [];

        return products.filter(Boolean).map(p => {
            let score = 0;
            const name = p.name || ''; const sku = p.sku || ''; const barcode = p.barcode || '';

            // Normalize product text once
            const normalizedProductText = normalizeSearchText(`${name} ${sku} ${barcode} ${(p.variants || []).map(v => `${v.sku || ''} ${v.barcode || ''} ${v.name || ''}`).join(' ')}`);

            // Check if ALL terms match the normalized product text
            if (!terms.every(term => normalizedProductText.includes(normalizeSearchText(term)))) return null;

            // Scoring (Keep existing simple logic or update to normalized - keeping simple for now but using normalized for exact matches)
            const lowerTerm = deferredSearchTerm.toLowerCase();
            const normalizedTerm = normalizeSearchText(deferredSearchTerm);
            const normalizedName = normalizeSearchText(name);
            const normalizedSku = normalizeSearchText(sku);
            const normalizedBarcode = normalizeSearchText(barcode);

            if (normalizedBarcode === normalizedTerm) score += 100;
            else if (normalizedSku === normalizedTerm) score += 90;
            else if (normalizedName === normalizedTerm) score += 80;
            else if (normalizedName.startsWith(normalizedTerm)) score += 50;
            score += 10;

            return { product: p, score };
        }).filter(Boolean).sort((a, b) => b.score - a.score).map(item => item.product).slice(0, 15);
    }, [deferredSearchTerm, products]);

    useEffect(() => {
        setSearchActiveIndex(filteredProducts.length > 0 ? 0 : -1);
    }, [deferredSearchTerm, filteredProducts.length]);

    // Actions
    const addToCart = (product) => {
        // --- Stock Check ---
        // For products with variants, stock is checked at the variant level in addVariantToCart or VariantSelectionModal.
        // For simple products, we check here.
        if ((!product.variants || product.variants.length === 0) && (product.stock !== undefined && product.stock !== null)) {
            if (product.stock <= 0 && settings?.billing?.allowNegativeStock !== true) {
                addToast(`Product "${product.name}" is out of stock!`, 'error');
                return;
            }
        }

        if (product.variants && product.variants.length > 0) {
            setSelectedProductForVariant(product);
            setModals(prev => ({ ...prev, variantSelection: true }));
            setSearchTerm('');
            return;
        }
        const productId = product.id || product._id;
        const price = product.price || product.sellingPrice || 0;
        let newCart = [...currentBill.cart];
        const existingIndex = newCart.findIndex(item => (item.id || item._id) === productId && !item.variantIndex);

        if (existingIndex > -1) {
            // Check stock for increment
            if (product.stock !== undefined && product.stock !== null) {
                if (newCart[existingIndex].quantity + 1 > product.stock && settings?.billing?.allowNegativeStock !== true) {
                    addToast(`Cannot add more. Reached stock limit for "${product.name}"`, 'error');
                    return;
                }
            }
            newCart[existingIndex].quantity += 1;
            const itemPrice = newCart[existingIndex].price || newCart[existingIndex].sellingPrice || 0;
            newCart[existingIndex].total = (newCart[existingIndex].quantity * itemPrice) - (newCart[existingIndex].discount || 0);
        } else {
            const taxRate = product.taxRate !== undefined ? product.taxRate : (product.tax_rate !== undefined ? product.tax_rate : 0);
            newCart.push({ ...product, quantity: 1, total: price, discount: 0, discountPercent: 0, taxRate: parseFloat(taxRate) || 0 });
        }
        updateCurrentBill({ cart: newCart });
        setSearchTerm('');

        // Continuous scanning: refocus search
        setTimeout(() => {
            searchInputRef.current?.focus();
        }, 0);
    };

    const addVariantToCart = (product, variant, variantIndex, quantity = 1) => {
        // --- Stock Check for Variant ---
        if (variant.stock !== undefined && variant.stock !== null) {
            if (variant.stock <= 0 && settings?.billing?.allowNegativeStock !== true) {
                addToast(`Variant "${variant.name || variant.options.join(' ')}" is out of stock!`, 'error');
                return;
            }
        }

        const productId = product.id || product._id;
        const price = variant.price || 0;
        let newCart = [...currentBill.cart];
        const existingIndex = newCart.findIndex(item => (item.id || item._id) === productId && item.variantIndex === variantIndex);

        if (existingIndex > -1) {
            // Check stock for increment
            if (variant.stock !== undefined && variant.stock !== null) {
                if (newCart[existingIndex].quantity + quantity > variant.stock && settings?.billing?.allowNegativeStock !== true) {
                    addToast(`Cannot add more. Reached stock limit for "${variant.name || variant.options.join(' ')}"`, 'error');
                    return;
                }
            }

            newCart[existingIndex].quantity += quantity;
            const itemPrice = newCart[existingIndex].price || newCart[existingIndex].sellingPrice || 0;
            newCart[existingIndex].total = (newCart[existingIndex].quantity * itemPrice) - (newCart[existingIndex].discount || 0);
        } else {
            // Basic initial check already done above, but ensuring quantity doesn't exceed if we supported adding > 1 initially (which we do via arg)
            if (variant.stock !== undefined && variant.stock !== null) {
                if (quantity > variant.stock && settings?.billing?.allowNegativeStock !== true) {
                    addToast(`Not enough stock. Available: ${variant.stock}`, 'error');
                    return;
                }
            }

            const taxRate = product.taxRate !== undefined ? product.taxRate : (product.tax_rate !== undefined ? product.tax_rate : 0);
            newCart.push({
                ...product, variantIndex, variantId: variant.id || variant._id, variantName: variant.name || variant.options[0], variantOptions: variant.options,
                price: variant.price, sellingPrice: variant.price, stock: variant.stock, quantity, total: price * quantity, discount: 0, taxRate: parseFloat(taxRate) || 0
            });
        }
        updateCurrentBill({ cart: newCart });
    };

    const updateQuantity = useCallback((id, newQty) => {
        if (newQty < 1) return;
        
        // Find the item in cart to check stock
        const cartItem = currentBill.cart.find(item => (item.id || item._id) === id);
        if (cartItem && cartItem.stock !== undefined && cartItem.stock !== null) {
            if (newQty > cartItem.stock && settings?.billing?.allowNegativeStock !== true) {
                addToast(`Cannot set quantity to ${newQty}. Only ${cartItem.stock} available in stock.`, 'error');
                return;
            }
        }
        
        setActiveBills(prevBills => {
            return prevBills.map(bill => {
                if (bill.id === activeBillId) {
                    const newCart = bill.cart.map(item => {
                        const itemId = item.id || item._id;
                        const price = item.price || item.sellingPrice || 0;
                        let discount = item.discount || 0;
                        if (itemId === id) {
                            const baseTotal = newQty * price;
                            if (item.discountPercent > 0) discount = (baseTotal * item.discountPercent) / 100;
                            return { ...item, quantity: newQty, discount: discount, total: Math.max(0, baseTotal - discount) };
                        }
                        return item;
                    });
                    return { ...bill, cart: newCart };
                }
                return bill;
            });
        });
    }, [activeBillId, currentBill.cart, settings?.billing?.allowNegativeStock, addToast]);

    const removeItem = useCallback((id) => {
        if (!id) return;
        setActiveBills(prevBills => {
            return prevBills.map(bill => {
                if (bill.id === activeBillId) {
                    const newCart = bill.cart.filter(item => (item.id || item._id) !== id);
                    return { ...bill, cart: newCart };
                }
                return bill;
            });
        });
        if (id === selectedItemId) setSelectedItemId(null);
        setTimeout(() => searchInputRef.current?.focus(), 300);
    }, [activeBillId, selectedItemId]);

    const handleRowClick = useCallback((id) => setSelectedItemId(id), []);
    const handleDiscountClick = useCallback((id) => {
        setSelectedItemId(id);
        setModals(prev => ({ ...prev, itemDiscount: true }));
    }, []);

    const handleF2 = () => {
        if (selectedItemId) {
            setModals(p => ({ ...p, quantityChange: true }));
        } else {
            addToast("Please select an item first", "error");
            searchInputRef.current?.focus();
        }
    };
    const handleCustomerChange = useCallback((customerData) => {
        updateCurrentBill({ customer: customerData });
    }, [updateCurrentBill]);

    const handleTaxTypeChange = useCallback((type) => {
        updateCurrentBill({ taxType: type });
    }, [updateCurrentBill]);

    const handlePaymentChange = useCallback((field, value) => {
        if (field === 'status') {
            let updates = { status: value };
            if (value === 'Unpaid') updates.amountReceived = 0;
            if (value === 'Paid') updates.amountReceived = totals.total; // Use derived totals from closure
            updateCurrentBill(updates);
        } else {
            updateCurrentBill({
                [field === 'mode' ? 'paymentMode' : 'amountReceived']: value
            });
        }
    }, [totals.total, updateCurrentBill]);

    const handleF3 = useCallback(() => {
        if (selectedItemId) {
            setModals(p => ({ ...p, itemDiscount: true }));
        } else {
            addToast("Please select an item first", "error");
            searchInputRef.current?.focus();
        }
    }, [selectedItemId]);

    const handleF4 = useCallback(() => {
        if (selectedItemId) {
            removeItem(selectedItemId);
        } else {
            addToast("Please select an item first", "error");
            searchInputRef.current?.focus();
        }
    }, [selectedItemId, removeItem]);

    const handleF8 = useCallback(() => setModals(p => ({ ...p, additionalCharges: true })), []);
    const handleF9 = useCallback(() => setModals(p => ({ ...p, billDiscount: true })), []);
    const handleF10 = useCallback(() => setModals(p => ({ ...p, loyaltyPoints: true })), []);
    const handleF12 = useCallback(() => setModals(p => ({ ...p, remarks: true })), []);

    const handleApplyItemDiscount = (val, isPercent) => {
        if (!selectedItemId) return;
        const newCart = currentBill.cart.map(item => {
            if ((item.id || item._id) === selectedItemId) {
                const price = item.price || item.sellingPrice || 0;
                const baseTotal = item.quantity * price;
                let discount = isPercent ? (baseTotal * val / 100) : val;
                return { ...item, discount, discountPercent: isPercent ? val : 0, total: Math.max(0, baseTotal - discount) };
            }
            return item;
        });
        updateCurrentBill({ cart: newCart });
    };

    const handleApplyBillDiscount = (val, isPercent) => {
        const subtotal = currentBill.cart.reduce((acc, item) => acc + item.total, 0);
        updateCurrentBill({ billDiscount: isPercent ? (subtotal * val / 100) : val });
    };
    const handleApplyAdditionalCharges = (val) => updateCurrentBill({ additionalCharges: val });
    const handleApplyLoyaltyRedemption = (val) => updateCurrentBill({ loyaltyPointsDiscount: val });
    const handleSaveRemarks = (text) => updateCurrentBill({ remarks: text });

    const handleSavePrint = useCallback(async (format = '80mm') => {
        if (isProcessing) return;
        if (currentBill.cart.length === 0) return alert("Cart is empty!");
        
        // Check for items with 0 quantity
        const zeroQuantityItems = currentBill.cart.filter(item => item.quantity <= 0);
        if (zeroQuantityItems.length > 0) {
            const itemNames = zeroQuantityItems.map(item => item.name).join(', ');
            const proceed = window.confirm(`The following items have 0 quantity:\n${itemNames}\n\nDo you want to remove them and proceed with billing?`);
            if (!proceed) return;
            // Remove items with 0 quantity
            const updatedCart = currentBill.cart.filter(item => item.quantity > 0);
            updateCurrentBill({ cart: updatedCart });
            if (updatedCart.length === 0) {
                addToast("Cart is now empty", "error");
                return;
            }
        }
        
        setIsProcessing(true);
        try {
            let customer = currentBill.customer;
            if (currentBill.customer?.phone && !currentBill.customer?.id) {
                customer = await findOrCreateCustomer({
                    mobile: currentBill.customer.phone, name: currentBill.customer.name || 'Customer',
                    whatsappOptIn: currentBill.customer.whatsappOptIn, smsOptIn: currentBill.customer.smsOptIn, source: 'POS'
                });
            }

            // CRITICAL FIX: Re-calculate totals to get enriched items with tax snapshots
            const { enrichedCart, totals } = calculateTotals(
                currentBill.cart,
                currentBill.billDiscount,
                currentBill.additionalCharges,
                currentBill.loyaltyPointsDiscount,
                currentBill.taxType,
                settings
            );

            // CALCULATE PAYMENT
            let paymentsPayload = [];
            let quantityError = false;
            // Validate Stock before saving
            currentBill.cart.forEach(item => {
                const stock = item.stock;
                if (stock !== undefined && stock !== null && item.quantity > stock && settings?.billing?.allowNegativeStock !== true) {
                    addToast(`Insufficient stock for ${item.name}`, 'error');
                    quantityError = true;
                }
            });
            if (quantityError) {
                setIsProcessing(false);
                return;
            }

            const amtReceived = parseFloat(currentBill.amountReceived) || 0;
            let finalStatus = currentBill.status;

            // Resolve Pending Status
            if (finalStatus === 'Pending') {
                if (amtReceived >= totals.total && totals.total > 0) finalStatus = 'Paid';
                else if (amtReceived > 0) finalStatus = 'Partially Paid';
                else finalStatus = 'Pending'; // Will prompt for payment method if not Credit
            }

            if (finalStatus === 'Paid') {
                if (!currentBill.paymentMode) {
                    addToast("Please select a payment method", "error");
                    setIsProcessing(false);
                    return;
                }
                paymentsPayload.push({
                    id: crypto.randomUUID(),
                    date: new Date(),
                    amount: totals.total,
                    method: currentBill.paymentMode
                });
            } else if (finalStatus === 'Partially Paid' || (finalStatus === 'Pending' && amtReceived > 0)) {
                // If Pending but has amount, treat as Partial for validation
                if (!currentBill.paymentMode) {
                    addToast("Please select a payment method", "error");
                    setIsProcessing(false);
                    return;
                }
                if (amtReceived <= 0) {
                    addToast("Please enter received amount", "error");
                    setIsProcessing(false);
                    return;
                }
                paymentsPayload.push({
                    id: crypto.randomUUID(),
                    date: new Date(),
                    amount: amtReceived,
                    method: currentBill.paymentMode
                });
                if (finalStatus === 'Pending') finalStatus = 'Partially Paid';
            } else if (finalStatus === 'Pending' && amtReceived === 0) {
                // User didn't select Paid/Partial/Unpaid and amount is 0. 
                // Force them to choose status OR default to Credit?
                // "User has control" -> Prompt them.
                addToast("Please select a Payment Status (Paid, Partial, or Credit)", "error");
                setIsProcessing(false);
                return;
            }
            // If Unpaid/Credit, paymentsPayload remains empty

            const payload = {
                customerId: customer?.id || null,
                customerName: customer?.fullName || customer?.name || 'Customer',
                customerMobile: customer?.phone || '',
                date: new Date(),
                // Use ENRICHED items which contain taxableValue, cgst, sgst, etc.
                items: enrichedCart.map(item => ({
                    productId: item.id || item._id, name: item.name, quantity: item.quantity, price: item.price,
                    total: item.total, discount: item.discount, taxRate: item.taxRate,
                    taxableValue: item.taxableValue || 0, cgst: item.cgst || 0, sgst: item.sgst || 0, igst: item.igst || 0, totalTax: item.totalTax || 0,
                    variantId: item.variantId, hsnCode: item.hsnCode, // Ensure HSN is passed
                    isInclusive: item.isInclusive // Critical for Print Display Logic
                })),
                grossTotal: totals.grossTotal, itemDiscount: totals.itemDiscount, subtotal: totals.subtotal,
                tax: totals.tax, discount: totals.discount, additionalCharges: totals.additionalCharges,
                roundOff: totals.roundOff, total: totals.total, paymentMethod: currentBill.paymentMode || '', /* Optional for backend if payments array used */
                status: finalStatus, amountReceived: finalStatus === 'Unpaid' ? 0 : (amtReceived > 0 ? amtReceived : totals.total),
                payments: paymentsPayload,
                taxType: currentBill.taxType, // Save tax type (Intra/Inter)
                cgst: totals.cgst, sgst: totals.sgst, igst: totals.igst, // Save tax totals
                // NEW: Add detailed billing fields
                remarks: currentBill.remarks || '',
                billDiscount: currentBill.billDiscount || 0,
                loyaltyPointsDiscount: currentBill.loyaltyPointsDiscount || 0
            };

            const savedBill = await addTransaction(payload);
            refreshProducts(); refreshCustomers();
            syncService.uploadEvent('INVOICE_CREATED', savedBill).catch(e => console.error(e));

            // Only print receipt for fully paid invoices
            // For Partial or Credit/Unpaid, save invoice but don't print
            if (finalStatus === 'Paid') {
                printReceipt(savedBill, format, settings);
                addToast(`Bill #${savedBill.id} saved and printing...`, 'success');
            } else {
                addToast(`Invoice #${savedBill.id} saved (${finalStatus}). Receipt will be available after full payment.`, 'info');
            }

            closeBill(activeBillId);
        } catch (error) {
            console.error(error);
            alert("Failed");
        } finally { setIsProcessing(false); }
    }, [isProcessing, currentBill, settings, activeBillId, addTransaction, refreshProducts, refreshCustomers, addToast, findOrCreateCustomer, closeBill]);

    const handleF6 = useCallback(() => {
        if (selectedItemId) {
            setModals(p => ({ ...p, quantityChange: true }));
        } else {
            addToast("Please select an item first", "error");
            searchInputRef.current?.focus();
        }
    }, [selectedItemId]);

    useKeyboardShortcuts({ 'F2': handleF2, 'F3': handleF3, 'F4': handleF4, 'F5': handleReset, 'F6': handleF6, 'F8': handleF8, 'F9': handleF9, 'F10': handleF10, 'F12': handleF12, 'Ctrl+P': handleSavePrint });

    const handleFunctionClick = useCallback((key) => {
        switch (key) {
            case 'F2': handleF2(); break;
            case 'F3': handleF3(); break;
            case 'F4': handleF4(); break;
            case 'F5': handleReset(); break;
            case 'F6': handleF6(); break;
            case 'F8': handleF8(); break;
            case 'F9': handleF9(); break;
            case 'F10': handleF10(); break;
            case 'F12': handleF12(); break;
            default: break;
        }
    }, [handleF2, handleF3, handleF4, handleReset, handleF6, handleF8, handleF9, handleF10, handleF12]);

    const handleSearchKeyDown = (e) => {
        if (!filteredProducts.length) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            setSearchActiveIndex(prev => (prev + 1) % filteredProducts.length);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            setSearchActiveIndex(prev => (prev - 1 + filteredProducts.length) % filteredProducts.length);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (searchActiveIndex >= 0 && filteredProducts[searchActiveIndex]) {
                addToCart(filteredProducts[searchActiveIndex]);
            } else if (filteredProducts.length > 0) {
                // If no item is highlighted but Enter is pressed, select the first one
                addToCart(filteredProducts[0]);
            }
        }
    };


    // Scroll active item into view
    useEffect(() => {
        if (searchActiveIndex >= 0 && suggestionsListRef.current) {
            const activeItem = suggestionsListRef.current.children[searchActiveIndex];
            if (activeItem) {
                activeItem.scrollIntoView({ block: 'nearest' });
            }
        }
    }, [searchActiveIndex]);

    return (
        <div className="flex flex-col h-full w-full bg-zinc-50 overflow-hidden">
            {/* Top Bar - Tabs & Tools */}
            <div className="shrink-0 flex justify-between items-center px-2 bg-white border-b shadow-sm h-10">
                <div className="flex gap-2 items-end h-full overflow-x-auto overflow-y-hidden no-scrollbar">
                    {activeBills.map(bill => (
                        <div key={bill.id} onClick={() => setActiveBillId(bill.id)} className={`flex items-center gap-2 px-4 py-2 border-t border-x rounded-t-lg text-xs font-bold cursor-pointer select-none relative top-[1px] transition-all ${bill.id === activeBillId ? 'bg-white border-zinc-200 border-b-transparent text-zinc-900 shadow-[0_-2px_10px_-5px_rgba(0,0,0,0.05)] z-10' : 'bg-zinc-100 border-zinc-200 text-zinc-500 hover:bg-zinc-50 hover:text-zinc-700'}`}>
                            <span>#{bill.id}</span>
                            {bill.id === activeBillId && <span className="text-[10px] text-zinc-400 font-normal ml-1">Alt+W</span>}
                            <X size={12} className="text-zinc-400 hover:text-zinc-900 cursor-pointer ml-1" onClick={(e) => { e.stopPropagation(); closeBill(bill.id); }} />
                        </div>
                    ))}
                    <button onClick={addNewBill} className="flex items-center gap-1 px-3 py-1.5 text-slate-600 hover:bg-slate-100 hover:text-black rounded-md text-xs font-semibold my-1 transition-colors" title="New Bill (Alt+T)">
                        <Plus size={14} /> <span className="hidden sm:inline">New Bill</span>
                    </button>
                    <button onClick={handleReset} className="flex items-center gap-1 px-3 py-1.5 text-red-500 hover:bg-red-50 hover:text-red-700 rounded-md text-xs font-semibold my-1 transition-colors ml-2" title="Reset Session (F5)">
                        <RefreshCcw size={14} /> <span className="hidden sm:inline">Reset <span className="opacity-75 font-normal ml-0.5">(F5)</span></span>
                    </button>
                </div>
            </div>

            {/* Main Workspace - 3 Panel Layout */}
            <div className="flex-1 min-h-0 flex p-3 gap-3 overflow-hidden">
                {/* CENTER PANEL: Billing Area (Search + Grid + Shortcuts) */}
                <div className="flex-1 flex flex-col min-w-0 bg-white rounded-xl border border-zinc-200 shadow-sm h-full relative overflow-hidden">
                    {/* 1. Search Bar (Fixed Top) */}
                    <div className="shrink-0 p-3 border-b border-slate-100 bg-white z-20">
                        <div className="relative flex gap-2">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 h-4 w-4" />
                                <Input id="main-search-input" ref={searchInputRef} autoFocus className="pl-10 h-11 text-sm bg-zinc-50 border-zinc-200 focus:bg-white focus:border-zinc-900 focus:ring-1 focus:ring-zinc-900 shadow-sm transition-all rounded-lg" placeholder="Scan barcode or search items..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} onKeyDown={handleSearchKeyDown} />
                            </div>
                        </div>
                        {/* Autocomplete Dropdown */}
                        {searchTerm && filteredProducts.length > 0 && (
                            <div ref={suggestionsListRef} className="absolute left-3 right-3 mt-1 bg-white border rounded-lg shadow-xl py-1 max-h-[300px] overflow-y-auto z-50">
                                {filteredProducts.map((product, index) => (
                                    <div key={product.id || product._id} className={`px-4 py-2 cursor-pointer flex justify-between items-center border-b border-slate-50 last:border-0 transition-colors ${index === searchActiveIndex ? 'bg-black' : 'hover:bg-slate-50'}`} onClick={() => addToCart(product)}>
                                        <div>
                                            <span className={`font-semibold block text-sm ${index === searchActiveIndex ? 'text-white' : 'text-slate-800'}`}>{product.name}</span>
                                            <div className={`flex items-center gap-2 text-xs ${index === searchActiveIndex ? 'text-slate-300' : 'text-slate-500'}`}>
                                                <span className={`px-1 rounded ${index === searchActiveIndex ? 'bg-zinc-800 text-white' : 'bg-slate-100'}`}>{product.sku}</span>
                                                <span className={index === searchActiveIndex ? 'text-slate-300' : 'text-slate-500'}>{product.category}</span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <span className={`font-bold block ${index === searchActiveIndex ? 'text-white' : 'text-black'}`}>₹{product.price || product.sellingPrice}</span>
                                            <span className={`text-xs ${product.stock < 5 ? (index === searchActiveIndex ? 'text-rose-300 font-medium' : 'text-red-600 font-medium') : (index === searchActiveIndex ? 'text-slate-300' : 'text-slate-400')}`}>Stock: {product.stock}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* 2. Billing Grid (Flexible Middle) */}
                    <div className="flex-1 min-h-0 bg-slate-50/30 overflow-hidden relative flex flex-col">
                        <BillingGrid
                            cart={enrichedCart} // Use enriched cart with calculated values
                            updateQuantity={updateQuantity}
                            removeItem={removeItem}
                            selectedItemId={selectedItemId}
                            onRowClick={handleRowClick}
                            onDiscountClick={handleDiscountClick}
                        />
                    </div>

                    {/* 3. Bottom Function Bar (Fixed Bottom) */}
                    <div className="shrink-0 border-t border-zinc-200 bg-white relative z-20">
                        <BottomFunctionBar onFunctionClick={handleFunctionClick} />
                    </div>
                </div>

                {/* RIGHT PANEL: Sidebar */}
                <div className="w-[340px] lg:w-[380px] xl:w-[400px] shrink-0 h-full flex flex-col overflow-hidden rounded-xl shadow-sm border border-zinc-200 bg-white">
                    <BillingSidebar
                        customer={currentBill.customer}
                        onCustomerChange={handleCustomerChange}
                        totals={totals} // Use derived totals
                        gstSummary={gstSummary} // Use derived totals
                        taxType={currentBill.taxType}
                        onTaxTypeChange={handleTaxTypeChange}
                        onPaymentChange={handlePaymentChange}
                        paymentMode={currentBill.paymentMode}
                        isProcessing={isProcessing}
                        paymentStatus={currentBill.status || 'Paid'}
                        amountReceived={currentBill.amountReceived}
                        onSavePrint={handleSavePrint}
                        onRemoveDiscount={() => handleApplyBillDiscount(0, false)}
                        onEditDiscount={() => setModals(prev => ({ ...prev, billDiscount: true }))}
                    />
                </div>
            </div>

            {/* Action Modals */}
            {/* Action Modals */}
            <DiscountModal
                isOpen={modals.itemDiscount}
                onClose={() => { setModals(prev => ({ ...prev, itemDiscount: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onApply={handleApplyItemDiscount}
                title={`Item Discount - ${currentBill.cart.find(i => (i.id || i._id) === selectedItemId)?.name || 'Unknown'}`}
                initialValue={currentBill.cart.find(i => (i.id || i._id) === selectedItemId)?.discountPercent || currentBill.cart.find(i => (i.id || i._id) === selectedItemId)?.discount || 0}
                isPercentage={!!currentBill.cart.find(i => (i.id || i._id) === selectedItemId)?.discountPercent}
                totalAmount={(() => { const item = currentBill.cart.find(i => (i.id || i._id) === selectedItemId); if (!item) return 0; return (parseFloat(item.price || item.sellingPrice) || 0) * (parseFloat(item.quantity) || 0); })()}
            />
            <DiscountModal
                isOpen={modals.billDiscount}
                onClose={() => { setModals(prev => ({ ...prev, billDiscount: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onApply={handleApplyBillDiscount}
                title="Bill Discount"
                initialValue={currentBill.billDiscount}
                totalAmount={totals.subtotal}
            />
            <AdditionalChargesModal
                isOpen={modals.additionalCharges}
                onClose={() => { setModals(prev => ({ ...prev, additionalCharges: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onApply={handleApplyAdditionalCharges}
                initialValue={currentBill.additionalCharges}
            />
            <LoyaltyPointsModal
                isOpen={modals.loyaltyPoints}
                onClose={() => { setModals(prev => ({ ...prev, loyaltyPoints: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onApply={handleApplyLoyaltyRedemption}
                availablePoints={250}
            />
            <RemarksModal
                isOpen={modals.remarks}
                onClose={() => { setModals(prev => ({ ...prev, remarks: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onSave={handleSaveRemarks}
                initialValue={currentBill.remarks}
            />
            <CustomerSearchModal
                isOpen={modals.customerSearch}
                onClose={() => { setModals(prev => ({ ...prev, customerSearch: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onSelect={(customer) => updateCurrentBill({ customer })}
            />
            <QuantityModal
                isOpen={modals.quantityChange}
                onClose={() => { setModals(prev => ({ ...prev, quantityChange: false })); setTimeout(() => searchInputRef.current?.focus(), 300); }}
                onApply={(newQty) => updateQuantity(selectedItemId, newQty)}
                item={currentBill.cart.find(i => (i.id || i._id) === selectedItemId)}
                allowNegativeStock={settings?.billing?.allowNegativeStock === true}
            />
            <VariantSelectionModal
                isOpen={modals.variantSelection}
                onClose={() => {
                    setModals(prev => ({ ...prev, variantSelection: false }));
                    setTimeout(() => searchInputRef.current?.focus(), 300);
                }}
                product={selectedProductForVariant}
                onAddToCart={(product, variant, variantIndex, quantity) => {
                    addVariantToCart(product, variant, variantIndex, quantity);
                    setModals(prev => ({ ...prev, variantSelection: false }));
                    setTimeout(() => searchInputRef.current?.focus(), 300);
                }}
            />

            <ConfirmationModal
                isOpen={isResetConfirmOpen}
                onClose={() => setIsResetConfirmOpen(false)}
                onConfirm={performReset}
                title="Reset Session?"
                message="Are you sure you want to reset the entire billing session? This will clear all bills and unsaved changes."
                variant="danger"
            />


        </div>
    );
}

export default BillingPage;



