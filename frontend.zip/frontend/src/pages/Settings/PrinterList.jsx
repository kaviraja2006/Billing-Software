import React from 'react';

// Helper Component for Printer Listing
const PrinterList = ({ selectedPrinter, onSelect }) => {
    const [printers, setPrinters] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const fetchPrinters = async () => {
            if (window.electron && window.electron.getPrinters) {
                try {
                    const list = await window.electron.getPrinters();
                    setPrinters(list);
                } catch (e) {
                    console.error("Failed to fetch printers", e);
                }
            }
            setLoading(false);
        };
        fetchPrinters();
    }, []);

    if (loading) return <div className="text-xs text-slate-500">Loading printers...</div>;

    return (
        <div className="space-y-2">
            <select
                className="w-full h-10 rounded-md border border-slate-200 px-3 bg-white text-sm focus:ring-2 focus:ring-black shadow-sm"
                value={selectedPrinter || ''}
                onChange={(e) => onSelect(e.target.value)}
            >
                <option value="">System Default</option>
                {printers.map(p => (
                    <option key={p.name} value={p.name}>{p.name} {p.isDefault ? '(Default)' : ''}</option>
                ))}
            </select>
        </div>
    );
};

export default PrinterList;
